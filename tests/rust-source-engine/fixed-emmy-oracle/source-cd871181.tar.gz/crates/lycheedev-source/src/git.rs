use crate::catalog;
use lycheedev_core::{
    Result, ToolkitError,
    control::OperationControl,
    selection::{SourcePin, valid_digest},
    storage::ExclusiveLock,
};
use sha1::{Digest, Sha1};
use std::{
    fs,
    io::Read,
    path::{Path, PathBuf},
    process::Command,
    time::Duration,
};

pub const PARSER: &str = "source-v1";
pub const MAX_SOURCE_BYTES: usize = 32 << 20;
pub fn source_path(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 4096
        && !value.starts_with('/')
        && value != "."
        && value != ".."
        && !value.contains(['\\', ':', '\0', '\r', '\n'])
        && value
            .split('/')
            .all(|p| !p.is_empty() && p != "." && p != "..")
}
pub fn mirror(home: &Path, key: &str) -> PathBuf {
    home.join("mirrors").join(format!("{key}.git"))
}
/// Read-only repository-format probe. This does not fetch, publish references,
/// authenticate every object, or claim a requested source pin is available.
pub fn mirror_health_with_control(
    home: &Path,
    key: &str,
    product: &str,
    control: &OperationControl,
) -> Result<serde_json::Value> {
    control.check()?;
    let repository = catalog::lookup(key)?;
    if !repository.tracks.contains_key(product) {
        return Err(ToolkitError::new(
            "codebase.unknown_product",
            "Unknown source product",
            2,
        ));
    }
    let path = mirror(home, key);
    lycheedev_core::storage::guard_path(home, &path)?;
    let metadata = match fs::symlink_metadata(&path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Ok(
                serde_json::json!({"repository":key,"product":product,"exists":false,"scope":"repository-format","objectsVerified":false}),
            );
        }
        Err(error) => return Err(error.into()),
    };
    if !metadata.is_dir() || metadata.file_type().is_symlink() {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Source mirror must be a regular contained directory",
            4,
        ));
    }
    let raw = bytes_with_control(
        Some(&path),
        &["rev-parse", "--is-bare-repository", "--show-object-format"],
        1024,
        control,
    )?;
    if raw != b"true\nsha1\n" && raw != b"true\r\nsha1\r\n" {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Source mirror must use a bare SHA-1 Git repository",
            4,
        ));
    }
    Ok(
        serde_json::json!({"repository":key,"product":product,"exists":true,"bare":true,"objectFormat":"sha1","scope":"repository-format","objectsVerified":false}),
    )
}

/// Git for Windows argv accepts ordinary DOS/UNC spellings, not Rust's
/// canonical verbatim prefix. File identities and containment stay canonical;
/// only the external process argument spelling is converted.
fn ordinary_argument(value: &str) -> std::borrow::Cow<'_, str> {
    if let Some(path) = value.strip_prefix("\\\\?\\UNC\\") {
        std::borrow::Cow::Owned(format!("\\\\{path}"))
    } else if let Some(path) = value.strip_prefix("\\\\?\\") {
        std::borrow::Cow::Borrowed(path)
    } else {
        std::borrow::Cow::Borrowed(value)
    }
}

/// Explicit byte transport, never a shell, no inherited Git routing/config/filter/replacements.
/// Both pipes are drained concurrently with caps. Timeout/output overflow kills and reaps.
pub fn bytes(directory: Option<&Path>, args: &[&str], cap: usize) -> Result<Vec<u8>> {
    bytes_with_input(directory, args, cap, None)
}
pub fn bytes_with_control(
    directory: Option<&Path>,
    args: &[&str],
    cap: usize,
    control: &lycheedev_core::control::OperationControl,
) -> Result<Vec<u8>> {
    control.check()?;
    bytes_controlled(
        directory,
        args,
        cap,
        None,
        control.remaining()?,
        Some(control.token()),
    )
}
fn bytes_with_input(
    directory: Option<&Path>,
    args: &[&str],
    cap: usize,
    input: Option<Vec<u8>>,
) -> Result<Vec<u8>> {
    bytes_with_deadline(directory, args, cap, input, Duration::from_secs(180))
}
fn bytes_with_deadline(
    directory: Option<&Path>,
    args: &[&str],
    cap: usize,
    input: Option<Vec<u8>>,
    timeout: Duration,
) -> Result<Vec<u8>> {
    bytes_controlled(directory, args, cap, input, timeout, None)
}
fn bytes_controlled(
    directory: Option<&Path>,
    args: &[&str],
    cap: usize,
    input: Option<Vec<u8>>,
    timeout: Duration,
    cancel: Option<&std::sync::atomic::AtomicBool>,
) -> Result<Vec<u8>> {
    let null = if cfg!(windows) { "NUL" } else { "/dev/null" };
    let mut cmd = Command::new("git");
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000);
    }
    cmd.args([
        "-c",
        &format!("core.hooksPath={null}"),
        "-c",
        "protocol.allow=never",
        "-c",
        "protocol.https.allow=always",
        "-c",
        "maintenance.auto=false",
        "-c",
        "gc.auto=0",
    ]);
    if let Some(dir) = directory {
        cmd.arg(format!(
            "--git-dir={}",
            ordinary_argument(&dir.to_string_lossy())
        ));
    }
    for arg in args {
        cmd.arg(&*ordinary_argument(arg));
    }
    for (key, _) in std::env::vars_os() {
        let upper = key.to_string_lossy().to_ascii_uppercase();
        if upper.starts_with("GIT_") || upper == "GCM_INTERACTIVE" {
            cmd.env_remove(key);
        }
    }
    cmd.env("GIT_CONFIG_NOSYSTEM", "1")
        .env("GIT_CONFIG_GLOBAL", null)
        .env("GIT_TERMINAL_PROMPT", "0")
        .env("GCM_INTERACTIVE", "never")
        .env("GIT_NO_REPLACE_OBJECTS", "1");
    let out = crate::process::run_with_limits(cmd, cap, 32768, timeout, input, cancel).map_err(
        |mut error| {
            error.code = match error.code.as_str() {
                "luals.unavailable" => "codebase.source_not_ready",
                "luals.input_budget" => "codebase.source_budget",
                "process.cancelled" => "command.cancelled",
                _ => "codebase.git_failed",
            }
            .into();
            error
        },
    )?;
    if out.status != 0 {
        return Err(ToolkitError::new(
            "codebase.git_failed",
            String::from_utf8_lossy(&out.stderr).trim(),
            5,
        ));
    }
    Ok(out.stdout)
}
/// Read only objects already authenticated by the pinned immutable tree. One
/// batch is bounded to 64 MiB plus framing; every returned object is rehashed.
pub fn visit_blobs(
    home: &Path,
    pin: &SourcePin,
    files: &[TreeFile],
    visit: impl FnMut(&TreeFile, Vec<u8>) -> Result<()>,
) -> Result<usize> {
    visit_blobs_until(
        home,
        pin,
        files,
        std::time::Instant::now() + Duration::from_secs(180),
        visit,
    )
}
pub(crate) fn visit_blobs_until(
    home: &Path,
    pin: &SourcePin,
    files: &[TreeFile],
    deadline: std::time::Instant,
    visit: impl FnMut(&TreeFile, Vec<u8>) -> Result<()>,
) -> Result<usize> {
    visit_blobs_controlled(home, pin, files, deadline, None, visit)
}
pub fn visit_blobs_with_control(
    home: &Path,
    pin: &SourcePin,
    files: &[TreeFile],
    control: &lycheedev_core::control::OperationControl,
    visit: impl FnMut(&TreeFile, Vec<u8>) -> Result<()>,
) -> Result<usize> {
    control.check()?;
    visit_blobs_controlled(home, pin, files, control.deadline(), Some(control), visit)
}
fn visit_blobs_controlled(
    home: &Path,
    pin: &SourcePin,
    files: &[TreeFile],
    deadline: std::time::Instant,
    control: Option<&lycheedev_core::control::OperationControl>,
    mut visit: impl FnMut(&TreeFile, Vec<u8>) -> Result<()>,
) -> Result<usize> {
    validate_pin(pin)?;
    let dir = mirror(home, &pin.repository);
    let admitted: Vec<_> = files
        .iter()
        .filter(|f| !f.oversized && (!f.asset || f.bytes <= 64 << 20))
        .collect();
    let mut first = 0;
    let mut batches = 0;
    while first < admitted.len() {
        if let Some(control) = control {
            control.check()?;
        }
        if std::time::Instant::now() >= deadline {
            return Err(ToolkitError::new(
                "codebase.source_budget",
                "Source execution deadline exceeded",
                3,
            ));
        }
        let mut last = first;
        let mut size = 0usize;
        while last < admitted.len() {
            let n = admitted[last].bytes;
            if last > first && (size + n > 64 << 20 || last - first >= 4096) {
                break;
            }
            size += n;
            last += 1;
        }
        let input = admitted[first..last]
            .iter()
            .map(|f| format!("{}\n", f.object))
            .collect::<String>()
            .into_bytes();
        let data = bytes_controlled(
            Some(&dir),
            &["cat-file", "--batch"],
            size + (last - first) * 128,
            Some(input),
            deadline.saturating_duration_since(std::time::Instant::now()),
            control.map(lycheedev_core::control::OperationControl::token),
        )?;
        let mut at = 0;
        for f in &admitted[first..last] {
            if let Some(control) = control {
                control.check()?;
            }
            let end = data[at..]
                .iter()
                .position(|b| *b == b'\n')
                .map(|n| at + n)
                .ok_or_else(|| {
                    ToolkitError::new(
                        "codebase.source_integrity",
                        "Missing batch object header",
                        4,
                    )
                })?;
            let expected = format!("{} blob {}", f.object, f.bytes);
            if data[at..end] != *expected.as_bytes() {
                return Err(ToolkitError::new(
                    "codebase.source_integrity",
                    "Batch object identity mismatch",
                    4,
                ));
            }
            at = end + 1;
            let end = at
                .checked_add(f.bytes)
                .filter(|n| *n < data.len())
                .ok_or_else(|| {
                    ToolkitError::new("codebase.source_integrity", "Truncated batch object", 4)
                })?;
            if data[end] != b'\n' {
                return Err(ToolkitError::new(
                    "codebase.source_integrity",
                    "Invalid batch terminator",
                    4,
                ));
            }
            let blob = &data[at..end];
            let mut hash = Sha1::new();
            hash.update(format!("blob {}\0", f.bytes));
            hash.update(blob);
            if format!("{:x}", hash.finalize()) != f.object {
                return Err(ToolkitError::new(
                    "codebase.source_integrity",
                    "Batch blob hash mismatch",
                    4,
                ));
            }
            visit(f, blob.to_vec())?;
            at = end + 1;
        }
        if at != data.len() {
            return Err(ToolkitError::new(
                "codebase.source_integrity",
                "Unexpected batch tail",
                4,
            ));
        }
        first = last;
        batches += 1;
    }
    Ok(batches)
}
pub fn validate_pin(pin: &SourcePin) -> Result<()> {
    let repo = catalog::lookup(&pin.repository)?;
    if !repo.tracks.contains_key(&pin.product)
        || !valid_digest(&pin.exact_commit, 40)
        || pin.parser_revision != PARSER
    {
        return Err(ToolkitError::new(
            "codebase.invalid_source_pin",
            "Source pin identity is invalid",
            4,
        ));
    }
    Ok(())
}
pub fn resolve_source(home: &Path, key: &str, product: &str, reference: &str) -> Result<SourcePin> {
    resolve_source_with_control(home, key, product, reference, &Default::default())
}
pub fn resolve_source_with_control(
    home: &Path,
    key: &str,
    product: &str,
    reference: &str,
    control: &OperationControl,
) -> Result<SourcePin> {
    control.check()?;
    let bytes = |directory: Option<&Path>, args: &[&str], cap: usize| {
        bytes_with_control(directory, args, cap, control)
    };
    let repo = catalog::lookup(key)?;
    let branch = repo.tracks.get(product).ok_or_else(|| {
        ToolkitError::new("codebase.unknown_product", "Unknown source product", 2)
    })?;
    let reference = if reference.is_empty() {
        format!("refs/heads/{branch}")
    } else {
        reference.into()
    };
    let mut invalid_ref = !valid_digest(&reference, 40)
        && !(reference.starts_with("refs/heads/") || reference.starts_with("refs/tags/"));
    if !valid_digest(&reference, 40)
        && !invalid_ref
        && let Err(error) = bytes(None, &["check-ref-format", &reference], 1024)
    {
        control.check()?;
        if error.exit_code == 7 {
            return Err(error);
        }
        invalid_ref = true;
    }
    if invalid_ref {
        return Err(ToolkitError::new(
            "codebase.invalid_source_ref",
            "Full branch/tag ref or exact commit required",
            2,
        ));
    }
    fs::create_dir_all(home.join("mirrors"))?;
    let _lock = ExclusiveLock::acquire(&home.join("locks").join(format!("source-{key}.lock")))?;
    let destination = mirror(home, key);
    let stage = home
        .join("mirrors")
        .join(format!(".source-{key}-{}", std::process::id()));
    let created = !destination.exists();
    let dir = if created { &stage } else { &destination };
    if created {
        if stage.exists() {
            return Err(ToolkitError::new(
                "codebase.source_not_ready",
                "Source staging path already exists",
                3,
            ));
        }
        bytes(
            None,
            &[
                "init",
                "--bare",
                "--object-format=sha1",
                &stage.to_string_lossy(),
            ],
            4096,
        )?;
    } else if !fs::symlink_metadata(dir)?.is_dir() {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Invalid mirror directory",
            4,
        ));
    }
    let result = (|| {
        bytes(
            Some(dir),
            &[
                "-c",
                "fetch.fsckObjects=true",
                "fetch",
                "--quiet",
                "--no-tags",
                "--no-recurse-submodules",
                "--depth=1",
                &repo.url,
                &reference,
            ],
            4096,
        )?;
        let commit = String::from_utf8_lossy(&bytes(
            Some(dir),
            &["rev-parse", "--verify", "FETCH_HEAD^{commit}"],
            128,
        )?)
        .trim()
        .to_owned();
        if !valid_digest(&commit, 40) || (valid_digest(&reference, 40) && commit != reference) {
            return Err(ToolkitError::new(
                "codebase.source_integrity",
                "Resolved source commit mismatch",
                4,
            ));
        }
        bytes(
            Some(dir),
            &["update-ref", &format!("refs/pins/{commit}"), &commit],
            1024,
        )?;
        if created {
            fs::rename(dir, &destination)?;
        }
        Ok(SourcePin {
            repository: key.into(),
            product: product.into(),
            requested_ref: reference,
            exact_commit: commit,
            parser_revision: PARSER.into(),
        })
    })();
    if created && stage.exists() {
        let _ = fs::remove_dir_all(&stage);
    }
    result
}
#[derive(Debug, Clone)]
pub struct TreeFile {
    pub path: String,
    pub object: String,
    pub bytes: usize,
    pub asset: bool,
    pub oversized: bool,
}
pub fn is_asset(ext: &str) -> bool {
    [
        "blp", "tga", "png", "jpg", "jpeg", "dds", "ttf", "otf", "mp3", "ogg", "wav", "m2", "wmo",
    ]
    .contains(&ext)
}
pub fn tree(home: &Path, pin: &SourcePin) -> Result<Vec<TreeFile>> {
    tree_listing(home, pin, false, None)
}
pub fn tree_with_control(
    home: &Path,
    pin: &SourcePin,
    control: &lycheedev_core::control::OperationControl,
) -> Result<Vec<TreeFile>> {
    tree_listing(home, pin, false, Some(control))
}
/// Complete regular-file checkout admission, including files outside source
/// query extensions. Symlinks/submodules fail admission instead of disappearing.
pub fn regular_tree(home: &Path, pin: &SourcePin) -> Result<Vec<TreeFile>> {
    tree_listing(home, pin, true, None)
}
pub fn regular_tree_with_control(
    home: &Path,
    pin: &SourcePin,
    control: &lycheedev_core::control::OperationControl,
) -> Result<Vec<TreeFile>> {
    tree_listing(home, pin, true, Some(control))
}
fn tree_listing(
    home: &Path,
    pin: &SourcePin,
    all_regular: bool,
    control: Option<&lycheedev_core::control::OperationControl>,
) -> Result<Vec<TreeFile>> {
    validate_pin(pin)?;
    let dir = mirror(home, &pin.repository);
    if let Some(control) = control {
        control.check()?;
    }
    let raw = bytes_controlled(
        Some(&dir),
        &[
            "ls-tree",
            "-r",
            "-l",
            "-z",
            "--full-tree",
            &pin.exact_commit,
        ],
        32 << 20,
        None,
        control
            .map(|c| c.remaining())
            .transpose()?
            .unwrap_or(Duration::from_secs(180)),
        control.map(lycheedev_core::control::OperationControl::token),
    )?;
    let mut files = Vec::new();
    let (mut documents, mut assets, mut total) = (0, 0, 0usize);
    for entry in raw.split(|b| *b == 0).filter(|e| !e.is_empty()) {
        if let Some(control) = control {
            control.check()?;
        }
        let Some(split) = entry.iter().position(|b| *b == b'\t') else {
            return Err(ToolkitError::new(
                "codebase.source_integrity",
                "Invalid Git tree record",
                4,
            ));
        };
        let header = std::str::from_utf8(&entry[..split])
            .map_err(|_| ToolkitError::invalid("Invalid Git tree encoding"))?;
        let fields: Vec<_> = header.split_whitespace().collect();
        if fields.len() != 4 {
            return Err(ToolkitError::invalid("Invalid Git tree fields"));
        }
        if fields[0] != "100644" && fields[0] != "100755" {
            if all_regular {
                return Err(ToolkitError::new(
                    "codebase.worktree_invalid",
                    "Pinned checkout contains a nonregular Git mode",
                    4,
                ));
            }
            continue;
        }
        let path = std::str::from_utf8(&entry[split + 1..])
            .map_err(|_| ToolkitError::invalid("Invalid source path encoding"))?;
        let ext = Path::new(path)
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        let doc = ["lua", "xml", "toc"].contains(&ext.as_str());
        let asset = is_asset(&ext);
        if !all_regular && !doc && !asset {
            continue;
        }
        let size: usize = fields[3]
            .parse()
            .map_err(|_| ToolkitError::invalid("Invalid Git blob size"))?;
        if fields[1] != "blob" || !valid_digest(fields[2], 40) || !source_path(path) {
            return Err(ToolkitError::new(
                "codebase.source_integrity",
                "Invalid source tree object",
                4,
            ));
        }
        if asset {
            assets += 1;
        } else {
            documents += 1;
        }
        let oversized = doc && size > MAX_SOURCE_BYTES;
        if all_regular && size > 128 << 20 {
            return Err(ToolkitError::new(
                "codebase.source_budget",
                "Checkout file byte budget exceeded",
                3,
            ));
        }
        if all_regular || !oversized && (!asset || size <= 64 << 20) {
            total = total.checked_add(size).ok_or_else(|| {
                ToolkitError::new("codebase.source_budget", "Source tree overflow", 3)
            })?;
        }
        if all_regular && (files.len() >= 200000 || total > 4usize << 30)
            || !all_regular && (documents > 100000 || assets > 200000 || total > 1 << 30)
        {
            return Err(ToolkitError::new(
                "codebase.source_budget",
                "Source tree budget exceeded",
                3,
            ));
        }
        files.push(TreeFile {
            path: path.into(),
            object: fields[2].into(),
            bytes: size,
            asset,
            oversized,
        });
    }
    Ok(files)
}
/// Verify one admitted checkout file against the Git framed blob hash. The
/// caller must guard its managed checkout boundary; this helper rejects links,
/// nonregular files, length changes and differing content.
pub fn verify_file(path: &Path, file: &TreeFile, max: usize) -> Result<()> {
    verify_file_controlled(path, file, max, None)
}
pub fn verify_file_with_control(
    path: &Path,
    file: &TreeFile,
    max: usize,
    control: &lycheedev_core::control::OperationControl,
) -> Result<()> {
    verify_file_controlled(path, file, max, Some(control))
}
fn verify_file_controlled(
    path: &Path,
    file: &TreeFile,
    max: usize,
    control: Option<&lycheedev_core::control::OperationControl>,
) -> Result<()> {
    if file.bytes > max || max > 128 << 20 || !valid_digest(&file.object, 40) {
        return Err(ToolkitError::new(
            "codebase.source_budget",
            "Checkout verification byte budget exceeded",
            3,
        ));
    }
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink()
        || !metadata.is_file()
        || metadata.len() != file.bytes as u64
    {
        return Err(ToolkitError::new(
            "codebase.worktree_modified",
            "Checkout file mode or byte count differs",
            4,
        ));
    }
    let mut input = fs::File::open(path)?;
    let mut hash = Sha1::new();
    hash.update(format!("blob {}\0", file.bytes).as_bytes());
    let deadline = std::time::Instant::now() + Duration::from_secs(180);
    let mut count = 0usize;
    let mut buffer = [0u8; 65536];
    loop {
        if let Some(control) = control {
            control.check()?;
        }
        if std::time::Instant::now() >= deadline {
            return Err(ToolkitError::new(
                "codebase.source_budget",
                "Checkout verification deadline exceeded",
                3,
            ));
        }
        let n = input.read(&mut buffer)?;
        if n == 0 {
            break;
        }
        count = count
            .checked_add(n)
            .ok_or_else(|| ToolkitError::invalid("Checkout byte count overflow"))?;
        if count > file.bytes {
            return Err(ToolkitError::new(
                "codebase.worktree_modified",
                "Checkout file grew during verification",
                4,
            ));
        }
        hash.update(&buffer[..n]);
    }
    if count != file.bytes
        || input.metadata()?.len() != file.bytes as u64
        || format!("{:x}", hash.finalize()) != file.object
    {
        return Err(ToolkitError::new(
            "codebase.worktree_modified",
            "Checkout file content differs from pinned Git blob",
            4,
        ));
    }
    Ok(())
}
pub fn blob(home: &Path, pin: &SourcePin, path: &str, max: usize) -> Result<(Vec<u8>, String)> {
    blob_controlled(home, pin, path, max, None)
}
pub fn blob_with_control(
    home: &Path,
    pin: &SourcePin,
    path: &str,
    max: usize,
    control: &lycheedev_core::control::OperationControl,
) -> Result<(Vec<u8>, String)> {
    control.check()?;
    blob_controlled(home, pin, path, max, Some(control))
}
fn blob_controlled(
    home: &Path,
    pin: &SourcePin,
    path: &str,
    max: usize,
    control: Option<&lycheedev_core::control::OperationControl>,
) -> Result<(Vec<u8>, String)> {
    validate_pin(pin)?;
    if !source_path(path) {
        return Err(ToolkitError::new(
            "codebase.invalid_span",
            "Invalid source path",
            2,
        ));
    }
    let dir = mirror(home, &pin.repository);
    // One process returns the commit, every parent tree and the leaf. Verify
    // framed Git SHA-1 AND each tree edge, retaining regular-file admission.
    // Resolving commit:path as a blob alone would accept a symlink's bytes.
    let components: Vec<_> = path.split('/').collect();
    if components.len() > 64 || max > MAX_SOURCE_BYTES {
        return Err(ToolkitError::new(
            "codebase.source_budget",
            "Source path/decode budget exceeded",
            3,
        ));
    }
    let mut requests = format!("{}\n{}^{{tree}}\n", pin.exact_commit, pin.exact_commit);
    for end in 1..components.len() {
        requests.push_str(&format!(
            "{}:{}\n",
            pin.exact_commit,
            components[..end].join("/")
        ));
    }
    requests.push_str(&format!("{}:{path}\n", pin.exact_commit));
    let batch = bytes_controlled(
        Some(&dir),
        &["cat-file", "--batch"],
        max + (16 << 20) + (1 << 20) + 8192,
        Some(requests.into_bytes()),
        control
            .map(|c| c.remaining())
            .transpose()?
            .unwrap_or(Duration::from_secs(180)),
        control.map(lycheedev_core::control::OperationControl::token),
    )?;
    let mut at = 0;
    let commit = take_batch_object(&batch, &mut at, &pin.exact_commit, "commit", 1 << 20)?;
    let commit_text =
        std::str::from_utf8(&commit).map_err(|_| ToolkitError::invalid("Invalid commit text"))?;
    let mut expected = commit_text
        .lines()
        .next()
        .and_then(|line| line.strip_prefix("tree "))
        .filter(|hash| valid_digest(hash, 40))
        .ok_or_else(|| ToolkitError::invalid("Commit omitted tree identity"))?
        .to_owned();
    let mut tree_bytes = 0usize;
    for (i, component) in components.iter().enumerate() {
        if let Some(control) = control {
            control.check()?;
        }
        let tree = take_batch_object(&batch, &mut at, &expected, "tree", 4 << 20)?;
        tree_bytes += tree.len();
        if tree_bytes > 16 << 20 {
            return Err(ToolkitError::new(
                "codebase.source_budget",
                "Parent tree byte budget exceeded",
                3,
            ));
        }
        let mut cursor = 0;
        let mut found = None;
        while cursor < tree.len() {
            let end = tree[cursor..]
                .iter()
                .position(|b| *b == 0)
                .map(|n| cursor + n)
                .ok_or_else(|| ToolkitError::invalid("Truncated tree entry"))?;
            let hash_end = end
                .checked_add(21)
                .filter(|n| *n <= tree.len())
                .ok_or_else(|| ToolkitError::invalid("Truncated tree object identity"))?;
            let entry = &tree[cursor..end];
            let split = entry
                .iter()
                .position(|b| *b == b' ')
                .ok_or_else(|| ToolkitError::invalid("Invalid tree mode"))?;
            if &entry[split + 1..] == component.as_bytes() {
                if found.is_some() {
                    return Err(ToolkitError::invalid("Duplicate tree path"));
                }
                let mode = &entry[..split];
                let admitted = if i + 1 == components.len() {
                    mode == b"100644" || mode == b"100755"
                } else {
                    mode == b"40000"
                };
                if !admitted {
                    return Err(ToolkitError::new(
                        "codebase.source_integrity",
                        "Pinned path is not a regular source file",
                        4,
                    ));
                }
                found = Some(
                    tree[end + 1..hash_end]
                        .iter()
                        .map(|b| format!("{b:02x}"))
                        .collect::<String>(),
                );
            }
            cursor = hash_end;
        }
        expected = found.ok_or_else(|| {
            ToolkitError::new("codebase.source_not_ready", "Pinned file is absent", 3)
        })?;
    }
    let data = take_batch_object(&batch, &mut at, &expected, "blob", max)?;
    if at != batch.len() {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Git blob content integrity failed",
            4,
        ));
    }
    Ok((data, expected))
}
fn take_batch_object(
    raw: &[u8],
    at: &mut usize,
    object: &str,
    kind: &str,
    max: usize,
) -> Result<Vec<u8>> {
    let header_end = raw[*at..]
        .iter()
        .position(|b| *b == b'\n')
        .map(|n| *at + n)
        .ok_or_else(|| {
            ToolkitError::new("codebase.source_integrity", "Missing Git batch header", 4)
        })?;
    let header = std::str::from_utf8(&raw[*at..header_end]).map_err(|_| {
        ToolkitError::new("codebase.source_integrity", "Invalid Git batch header", 4)
    })?;
    let fields: Vec<_> = header.split(' ').collect();
    if fields.len() != 3 || fields[0] != object || fields[1] != kind {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Pinned object type or identity differs",
            4,
        ));
    }
    let size: usize = fields[2]
        .parse()
        .map_err(|_| ToolkitError::new("codebase.source_integrity", "Invalid Git batch size", 4))?;
    if size > max {
        return Err(ToolkitError::new(
            "codebase.source_budget",
            "Git object budget exceeded",
            3,
        ));
    }
    let start = header_end + 1;
    let end = start
        .checked_add(size)
        .filter(|end| *end < raw.len())
        .ok_or_else(|| {
            ToolkitError::new("codebase.source_integrity", "Truncated Git batch bytes", 4)
        })?;
    if raw[end] != b'\n' {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Invalid Git batch separator",
            4,
        ));
    }
    let mut hash = Sha1::new();
    hash.update(format!("{kind} {size}\0"));
    hash.update(&raw[start..end]);
    if format!("{:x}", hash.finalize()) != object {
        return Err(ToolkitError::new(
            "codebase.source_integrity",
            "Pinned Git object hash differs",
            4,
        ));
    }
    *at = end + 1;
    Ok(raw[start..end].to_vec())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn actual_batch_transport_matches_immutable_reader_and_rejects_identity_change() {
        let home = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../.tmp/rust-source-batch-tests")
            .join(format!(
                "{}-{}",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
        lycheedev_core::workspace::initialize(&home).unwrap();
        assert_eq!(
            mirror_health_with_control(&home, "wow-ui-source", "retail", &Default::default())
                .unwrap()["exists"],
            false
        );
        fs::create_dir_all(home.join("mirrors")).unwrap();
        let dir = mirror(&home, "wow-ui-source");
        bytes(
            None,
            &[
                "init",
                "--bare",
                "--object-format=sha1",
                &dir.to_string_lossy(),
            ],
            4096,
        )
        .unwrap();
        let health =
            mirror_health_with_control(&home, "wow-ui-source", "retail", &Default::default())
                .unwrap();
        assert_eq!(health["bare"], true);
        assert_eq!(health["objectFormat"], "sha1");
        assert_eq!(health["objectsVerified"], false);
        let input = b"function Exact()\r\n return 2\r\nend\r\n";
        let object = String::from_utf8(
            bytes_with_input(
                Some(&dir),
                &["hash-object", "-w", "--stdin"],
                128,
                Some(input.to_vec()),
            )
            .unwrap(),
        )
        .unwrap();
        let object = object.trim();
        let tree = String::from_utf8(
            bytes_with_input(
                Some(&dir),
                &["mktree"],
                128,
                Some(format!("100644 blob {object}\tFixture.lua\n").into_bytes()),
            )
            .unwrap(),
        )
        .unwrap();
        let tree = tree.trim();
        let commit = String::from_utf8(
            bytes(
                Some(&dir),
                &[
                    "-c",
                    "user.name=Rust fixture",
                    "-c",
                    "user.email=fixture@example.invalid",
                    "commit-tree",
                    tree,
                    "-m",
                    "isolated immutable source fixture",
                ],
                128,
            )
            .unwrap(),
        )
        .unwrap();
        let pin = SourcePin {
            repository: "wow-ui-source".into(),
            product: "retail".into(),
            requested_ref: "fixture".into(),
            exact_commit: commit.trim().into(),
            parser_revision: PARSER.into(),
        };
        let canonical_home = fs::canonicalize(&home).unwrap();
        let canonical_files = tree_fn(&canonical_home, &pin);
        let files = tree_fn(&home, &pin);
        assert_eq!(canonical_files[0].object, files[0].object);
        let mut canonical_bytes = vec![];
        visit_blobs(&canonical_home, &pin, &canonical_files, |_, bytes| {
            canonical_bytes = bytes;
            Ok(())
        })
        .unwrap();
        assert_eq!(canonical_bytes, input);
        let mut observed = vec![];
        visit_blobs(&home, &pin, &files, |f, data| {
            observed.push((f.path.clone(), data));
            Ok(())
        })
        .unwrap();
        assert_eq!(observed, vec![("Fixture.lua".into(), input.to_vec())]);
        assert_eq!(
            blob(&home, &pin, "Fixture.lua", MAX_SOURCE_BYTES)
                .unwrap()
                .0,
            input
        );
        let before_status = crate::query_store::status(&home, &pin).unwrap();
        assert_eq!(before_status["ready"], false);
        let first_index = crate::index::build(&home, &pin).unwrap();
        let status = crate::query_store::status(&home, &pin).unwrap();
        assert_eq!(status["ready"], true);
        assert_eq!(status["snapshotFiles"], 1);
        assert_eq!(status["astFiles"], 1);
        assert_eq!(status["storage"], "file-cache");
        assert_eq!(first_index.summary["io"]["gitBlobProcesses"], 1);
        assert_eq!(first_index.summary["io"]["parsedDocuments"], 1);
        let first_query = first_index
            .search(&pin, "PIN-fixture", "Exact", "precise", "lua", 1, "")
            .unwrap();
        assert_eq!(first_query["results"][0]["matchedBy"], "exact_symbol");
        assert_eq!(first_query["results"][0]["sourceSpan"]["startByte"], 0);
        assert_eq!(
            first_query["results"][0]["sourceSpan"]["endByte"],
            input.len()
        );
        assert_eq!(first_query["analysis"]["semantic"], "not_requested");
        assert!(serde_json::to_vec(&first_query).unwrap().len() < 4096);
        let hot = crate::index::build(&home, &pin).unwrap();
        assert_eq!(hot.summary["io"]["cachedFacts"], 1);
        assert_eq!(hot.symbols[0].id, first_index.symbols[0].id);
        let hot_query = hot
            .search(&pin, "PIN-fixture", "Exact", "precise", "lua", 1, "")
            .unwrap();
        assert_eq!(hot_query["results"], first_query["results"]);
        assert_eq!(hot_query["coverage"]["io"]["sourceDocumentsRead"], 1);
        let cache = fs::read_dir(home.join("cache/source-facts-rust"))
            .unwrap()
            .next()
            .unwrap()
            .unwrap()
            .path();
        lycheedev_core::storage::atomic_json(&cache,&serde_json::json!({"schema":"lycheedev.source-facts.rust.v2","facts":{"legacyLayout":true}})).unwrap();
        let mut metadata = lycheedev_core::metadata::Metadata::open(&home, true).unwrap();
        let mut old_index: serde_json::Value = metadata
            .list("source/rust-index/", 1)
            .unwrap()
            .pop()
            .unwrap();
        old_index["schema"] = serde_json::json!("lycheedev.source-index.rust.v3");
        let key = format!(
            "source/rust-index/{}",
            old_index["identity"].as_str().unwrap()
        );
        let generation = metadata.generation(&key).unwrap();
        metadata.put(&key, &old_index, generation).unwrap();
        let rebuilt = crate::index::build(&home, &pin).unwrap();
        assert_eq!(rebuilt.summary["io"]["parsedDocuments"], 1);
        assert_eq!(rebuilt.symbols[0].id, first_index.symbols[0].id);
        let mut tampered = files.clone();
        tampered[0].bytes += 1;
        assert_eq!(
            visit_blobs(&home, &pin, &tampered, |_, _| Ok(()))
                .unwrap_err()
                .code,
            "codebase.source_integrity"
        );
        drop(metadata);
        fs::remove_dir_all(home).unwrap();
    }
    fn tree_fn(home: &Path, pin: &SourcePin) -> Vec<TreeFile> {
        tree(home, pin).unwrap()
    }
    #[test]
    fn path_admission() {
        for p in [
            "",
            "../a.lua",
            "a/../b.lua",
            "/a.lua",
            "a\\b.lua",
            "a//b.lua",
            "a\0.lua",
            "C:a.lua",
        ] {
            assert!(!source_path(p));
        }
        assert!(source_path("Interface/FrameXML/UIParent.lua"));
    }
}
